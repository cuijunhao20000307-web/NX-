SchoolStealth3D v0.2 是原创第三人称校园潜行3D测试版，并非《病娇模拟器》原版。解压后将 switch/SchoolStealth3D/SchoolStealth3D.nro 放入 SD 卡同名目录；通过 hbmenu 启动。左摇杆移动、右摇杆转镜头、ZL潜行、ZR奔跑、A互动、X重置、+退出。尚未在 Switch 真机测试。
