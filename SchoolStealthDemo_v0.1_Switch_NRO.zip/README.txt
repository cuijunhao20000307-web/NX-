SchoolStealthDemo v0.1 - Nintendo Switch native homebrew TEST
This is an original school stealth prototype, NOT Yandere Simulator.
Install: copy SchoolStealthDemo.nro to sdmc:/switch/SchoolStealthDemo/
Launch with hbmenu in Atmosphere.
Built with devkitPro devkitA64/libnx via GitHub Actions on 2026-11-15.
It has NOT been tested on actual Switch hardware.
